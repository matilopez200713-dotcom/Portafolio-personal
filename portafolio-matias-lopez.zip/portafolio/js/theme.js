/* Modo claro/oscuro: cambia data-theme en <html> (variables en :root) */
(function () {
    var guardado = null;
    try { guardado = localStorage.getItem('tema'); } catch (e) {}
    document.documentElement.setAttribute('data-theme', guardado || 'dark');

    document.addEventListener('DOMContentLoaded', function () {
        var btn = document.getElementById('tema-btn');
        function actualizar() {
            btn.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? 'Modo claro' : 'Modo oscuro';
        }
        actualizar();
        btn.addEventListener('click', function () {
            var nuevo = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', nuevo);
            try { localStorage.setItem('tema', nuevo); } catch (e) {}
            actualizar();
        });
    });
})();
